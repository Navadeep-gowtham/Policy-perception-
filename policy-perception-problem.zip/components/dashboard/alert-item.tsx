"use client"

import { cn } from "@/lib/utils"
import { AlertTriangle, TrendingDown, Users } from "lucide-react"

interface AlertItemProps {
  type: "sentiment" | "collaboration" | "participation"
  message: string
  severity: "low" | "medium" | "high"
  className?: string
}

export function AlertItem({ type, message, severity, className }: AlertItemProps) {
  const icons = {
    sentiment: TrendingDown,
    collaboration: Users,
    participation: AlertTriangle,
  }

  const severityColors = {
    low: "border-warning/30 bg-warning/5",
    medium: "border-warning/50 bg-warning/10",
    high: "border-destructive/50 bg-destructive/10",
  }

  const iconColors = {
    low: "text-warning",
    medium: "text-warning",
    high: "text-destructive",
  }

  const Icon = icons[type]

  return (
    <div
      className={cn(
        "flex items-start gap-3 rounded-lg border p-3",
        severityColors[severity],
        className
      )}
    >
      <Icon className={cn("h-4 w-4 mt-0.5 shrink-0", iconColors[severity])} />
      <p className="text-sm text-foreground">{message}</p>
    </div>
  )
}
