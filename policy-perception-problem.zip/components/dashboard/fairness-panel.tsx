"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { HealthBar } from "./health-bar"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Cell,
} from "recharts"

const roleData = [
  { role: "Engineering", fairness: 72, burden: 45 },
  { role: "Sales", fairness: 85, burden: 30 },
  { role: "Design", fairness: 68, burden: 55 },
  { role: "Operations", fairness: 91, burden: 25 },
  { role: "Marketing", fairness: 78, burden: 40 },
  { role: "Finance", fairness: 82, burden: 35 },
]

const chartConfig = {
  fairness: {
    label: "Perceived Fairness",
    color: "var(--color-chart-1)",
  },
  burden: {
    label: "Burden Index",
    color: "var(--color-chart-4)",
  },
} satisfies ChartConfig

export function FairnessPanel() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-border bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Role-Based Legitimacy
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <HealthBar
                label="Physical presence creates value"
                value={74}
                change={-8}
                changeLabel="since policy"
              />
              <HealthBar
                label="Requirements match role needs"
                value={68}
                change={-12}
                changeLabel="since policy"
              />
              <HealthBar
                label="Equipment dependencies justified"
                value={89}
                change={2}
                changeLabel="since policy"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Procedural Justice
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <HealthBar
                label="Consulted before policy"
                value={42}
                change={0}
                changeLabel="baseline"
              />
              <HealthBar
                label="Accommodation requests normalized"
                value={56}
                change={-15}
                changeLabel="since policy"
              />
              <HealthBar
                label="Leadership follows same rules"
                value={38}
                change={-22}
                changeLabel="since policy"
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Fairness Perception by Role
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[280px] w-full">
            <BarChart data={roleData} layout="vertical">
              <XAxis type="number" domain={[0, 100]} tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }} />
              <YAxis dataKey="role" type="category" width={80} tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="fairness" fill="var(--color-chart-1)" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      <Card className="border-border bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Circumstantial Equity Assessment
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-lg border border-border bg-secondary/50 p-4">
              <p className="text-xs text-muted-foreground">Commute Burden Gap</p>
              <p className="mt-1 text-2xl font-semibold">47min</p>
              <p className="mt-1 text-xs text-destructive">High variance detected</p>
            </div>
            <div className="rounded-lg border border-border bg-secondary/50 p-4">
              <p className="text-xs text-muted-foreground">Caregiving Conflicts</p>
              <p className="mt-1 text-2xl font-semibold">23%</p>
              <p className="mt-1 text-xs text-warning">Moderate concern</p>
            </div>
            <div className="rounded-lg border border-border bg-secondary/50 p-4">
              <p className="text-xs text-muted-foreground">Accommodation Requests</p>
              <p className="mt-1 text-2xl font-semibold">156</p>
              <p className="mt-1 text-xs text-muted-foreground">+89% since policy</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
