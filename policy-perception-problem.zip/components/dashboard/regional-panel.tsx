"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RegionCard } from "./region-card"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import { RadarChart, PolarGrid, PolarAngleAxis, Radar } from "recharts"

const regions = [
  {
    name: "Americas",
    policy: "3 days/week, Flex Friday",
    engagement: 72,
    compliance: 89,
    attrition: 8.2,
    status: "on-track" as const,
  },
  {
    name: "EMEA",
    policy: "2 days/week, August flex",
    engagement: 81,
    compliance: 94,
    attrition: 5.1,
    status: "on-track" as const,
  },
  {
    name: "Asia-Pacific",
    policy: "4 days/week, Core hours adjusted",
    engagement: 68,
    compliance: 97,
    attrition: 11.3,
    status: "at-risk" as const,
  },
]

const radarData = [
  { dimension: "Engagement", Americas: 72, EMEA: 81, APAC: 68 },
  { dimension: "Compliance", Americas: 89, EMEA: 94, APAC: 97 },
  { dimension: "Satisfaction", Americas: 68, EMEA: 79, APAC: 54 },
  { dimension: "Collaboration", Americas: 74, EMEA: 82, APAC: 71 },
  { dimension: "Retention", Americas: 78, EMEA: 88, APAC: 62 },
]

const chartConfig = {
  Americas: {
    label: "Americas",
    color: "var(--color-chart-1)",
  },
  EMEA: {
    label: "EMEA",
    color: "var(--color-chart-2)",
  },
  APAC: {
    label: "Asia-Pacific",
    color: "var(--color-chart-3)",
  },
} satisfies ChartConfig

const governanceLayers = [
  {
    layer: "Global Principles",
    description: "Values, Core Hours, Minimum Standards, Tools",
    scope: "Consistent Everywhere",
    examples: ["Trust-based management", "4-hour overlap window", "Unified communication tools"],
  },
  {
    layer: "Regional Frameworks",
    description: "Bounded flexibility within guardrails",
    scope: "Adapted by Region",
    examples: ["Americas: Flex Fridays", "EMEA: August flexibility", "APAC: Adjusted core hours"],
  },
  {
    layer: "Team Agreements",
    description: "Local ownership of working norms",
    scope: "Team-Level Autonomy",
    examples: ["Sprint day preferences", "Meeting-free blocks", "Async communication windows"],
  },
]

export function RegionalPanel() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        {regions.map((region) => (
          <RegionCard key={region.name} {...region} />
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-border bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Regional Performance Comparison
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center gap-6 mb-4 text-xs">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-1" />
                Americas
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-2" />
                EMEA
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-3" />
                Asia-Pacific
              </span>
            </div>
            <ChartContainer config={chartConfig} className="h-[280px] w-full">
              <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="70%">
                <PolarGrid stroke="var(--color-border)" />
                <PolarAngleAxis
                  dataKey="dimension"
                  tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
                />
                <Radar
                  name="Americas"
                  dataKey="Americas"
                  stroke="var(--color-chart-1)"
                  fill="var(--color-chart-1)"
                  fillOpacity={0.2}
                  strokeWidth={2}
                />
                <Radar
                  name="EMEA"
                  dataKey="EMEA"
                  stroke="var(--color-chart-2)"
                  fill="var(--color-chart-2)"
                  fillOpacity={0.2}
                  strokeWidth={2}
                />
                <Radar
                  name="APAC"
                  dataKey="APAC"
                  stroke="var(--color-chart-3)"
                  fill="var(--color-chart-3)"
                  fillOpacity={0.2}
                  strokeWidth={2}
                />
                <ChartTooltip content={<ChartTooltipContent />} />
              </RadarChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Tiered Governance Framework
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {governanceLayers.map((item, index) => (
              <div
                key={item.layer}
                className={`rounded-lg border p-4 ${
                  index === 0
                    ? "border-chart-1/30 bg-chart-1/5"
                    : index === 1
                      ? "border-chart-2/30 bg-chart-2/5"
                      : "border-border bg-secondary/30"
                }`}
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-sm">{item.layer}</h4>
                  <span className="text-xs text-muted-foreground">{item.scope}</span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{item.description}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {item.examples.map((example) => (
                    <span
                      key={example}
                      className="rounded-full bg-secondary px-2 py-0.5 text-xs text-muted-foreground"
                    >
                      {example}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="border-border bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Cultural Dimension Impact Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="py-3 text-left font-medium text-muted-foreground">Dimension</th>
                  <th className="py-3 text-left font-medium text-muted-foreground">Americas</th>
                  <th className="py-3 text-left font-medium text-muted-foreground">EMEA</th>
                  <th className="py-3 text-left font-medium text-muted-foreground">Asia-Pacific</th>
                  <th className="py-3 text-left font-medium text-muted-foreground">Presence Implication</th>
                </tr>
              </thead>
              <tbody>
                {[
                  {
                    dimension: "Collectivism",
                    americas: "Low",
                    emea: "Medium",
                    apac: "High",
                    implication: "Group presence rituals valued differently",
                  },
                  {
                    dimension: "Power Distance",
                    americas: "Low",
                    emea: "Low-Med",
                    apac: "High",
                    implication: "Visibility to leadership matters more in APAC",
                  },
                  {
                    dimension: "Work-Life Integration",
                    americas: "Blended",
                    emea: "Separated",
                    apac: "Blended",
                    implication: "Legal boundaries differ (EU regulations)",
                  },
                  {
                    dimension: "Avg Commute",
                    americas: "32 min",
                    emea: "28 min",
                    apac: "52 min",
                    implication: "Presence burden varies significantly",
                  },
                ].map((row) => (
                  <tr key={row.dimension} className="border-b border-border/50">
                    <td className="py-3 font-medium">{row.dimension}</td>
                    <td className="py-3 text-muted-foreground">{row.americas}</td>
                    <td className="py-3 text-muted-foreground">{row.emea}</td>
                    <td className="py-3 text-muted-foreground">{row.apac}</td>
                    <td className="py-3 text-muted-foreground">{row.implication}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Card className="border-warning/30 bg-warning/5">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="rounded-lg bg-warning/20 p-2">
              <svg className="h-5 w-5 text-warning" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <div>
              <h4 className="font-medium">Asia-Pacific Region Alert</h4>
              <p className="mt-1 text-sm text-muted-foreground">
                High compliance (97%) paired with low engagement (68%) and elevated attrition (11.3%) suggests coerced presence rather than genuine adoption. 
                Consider regional policy adjustment or enhanced local consultation.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
