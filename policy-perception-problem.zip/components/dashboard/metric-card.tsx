"use client"

import { cn } from "@/lib/utils"
import { ArrowDown, ArrowRight, ArrowUp } from "lucide-react"

interface MetricCardProps {
  title: string
  value: string | number
  suffix?: string
  change?: number
  changeLabel?: string
  status?: "healthy" | "warning" | "critical" | "neutral"
  className?: string
}

export function MetricCard({
  title,
  value,
  suffix = "%",
  change,
  changeLabel = "from baseline",
  status = "neutral",
  className,
}: MetricCardProps) {
  const statusColors = {
    healthy: "bg-success/10 border-success/20",
    warning: "bg-warning/10 border-warning/20",
    critical: "bg-destructive/10 border-destructive/20",
    neutral: "bg-card border-border",
  }

  const changeIcon = change
    ? change > 0
      ? ArrowUp
      : change < 0
        ? ArrowDown
        : ArrowRight
    : null

  const changeColor = change
    ? change > 0
      ? "text-success"
      : change < 0
        ? "text-destructive"
        : "text-muted-foreground"
    : "text-muted-foreground"

  return (
    <div
      className={cn(
        "rounded-lg border p-4",
        statusColors[status],
        className
      )}
    >
      <p className="text-sm text-muted-foreground">{title}</p>
      <div className="mt-2 flex items-baseline gap-2">
        <span className="text-2xl font-semibold tracking-tight">
          {value}
          {suffix}
        </span>
      </div>
      {change !== undefined && (
        <div className={cn("mt-2 flex items-center gap-1 text-xs", changeColor)}>
          {change > 0 && <ArrowUp className="h-3 w-3" />}
          {change < 0 && <ArrowDown className="h-3 w-3" />}
          {change === 0 && <ArrowRight className="h-3 w-3" />}
          <span>
            {Math.abs(change)}% {changeLabel}
          </span>
        </div>
      )}
    </div>
  )
}
