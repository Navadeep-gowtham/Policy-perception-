"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertItem } from "./alert-item"
import { HealthBar } from "./health-bar"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import { LineChart, Line, XAxis, YAxis, ReferenceLine } from "recharts"

const trustErosionData = [
  { week: "W1", trust: 82 },
  { week: "W2", trust: 80 },
  { week: "W3", trust: 78 },
  { week: "W4", trust: 74 },
  { week: "W5", trust: 71 },
  { week: "W6", trust: 68 },
  { week: "W7", trust: 65 },
  { week: "W8", trust: 63 },
]

const chartConfig = {
  trust: {
    label: "Trust Index",
    color: "var(--color-chart-1)",
  },
} satisfies ChartConfig

const signalCategories = [
  {
    name: "Participation Quality",
    signals: [
      { label: "Meeting engagement", value: 67, change: -15 },
      { label: "Initiative volunteering", value: 52, change: -28 },
      { label: "Question frequency", value: 61, change: -19 },
    ],
  },
  {
    name: "Network Behavior",
    signals: [
      { label: "Cross-team messages", value: 58, change: -22 },
      { label: "Informal mentoring", value: 45, change: -31 },
      { label: "Social participation", value: 42, change: -35 },
    ],
  },
  {
    name: "Boundary Patterns",
    signals: [
      { label: "Strict hours adherence", value: 78, change: 45 },
      { label: "Scope limitation", value: 64, change: 32 },
      { label: "Development opt-out", value: 38, change: 89 },
    ],
  },
]

const alerts = [
  {
    type: "sentiment" as const,
    message: "Engineering team sentiment declining 3 consecutive weeks",
    severity: "high" as const,
  },
  {
    type: "collaboration" as const,
    message: "Cross-functional collaboration down 18% in Product + Design",
    severity: "medium" as const,
  },
  {
    type: "participation" as const,
    message: "L&D participation dropped 40% since policy change",
    severity: "high" as const,
  },
  {
    type: "sentiment" as const,
    message: "\"They/them\" pronoun usage increasing in survey responses",
    severity: "medium" as const,
  },
]

export function EarlyWarningPanel() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Participation Health</p>
            <div className="mt-2 flex items-end gap-2">
              <span className="text-3xl font-semibold">60%</span>
              <span className="text-sm text-destructive mb-1">-21%</span>
            </div>
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <div className="h-full w-[60%] bg-warning transition-all" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Network Vitality</p>
            <div className="mt-2 flex items-end gap-2">
              <span className="text-3xl font-semibold">48%</span>
              <span className="text-sm text-destructive mb-1">-29%</span>
            </div>
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <div className="h-full w-[48%] bg-destructive transition-all" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Discretionary Effort</p>
            <div className="mt-2 flex items-end gap-2">
              <span className="text-3xl font-semibold">54%</span>
              <span className="text-sm text-destructive mb-1">-26%</span>
            </div>
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <div className="h-full w-[54%] bg-warning transition-all" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Sentiment Trend</p>
            <div className="mt-2 flex items-end gap-2">
              <span className="text-3xl font-semibold">43%</span>
              <span className="text-sm text-destructive mb-1">-34%</span>
            </div>
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <div className="h-full w-[43%] bg-destructive transition-all" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-border bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Trust Erosion Timeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-[200px] w-full">
              <LineChart data={trustErosionData}>
                <XAxis dataKey="week" tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }} />
                <YAxis domain={[50, 100]} tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }} />
                <ReferenceLine y={70} stroke="var(--color-warning)" strokeDasharray="3 3" />
                <ReferenceLine y={60} stroke="var(--color-destructive)" strokeDasharray="3 3" />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line
                  type="monotone"
                  dataKey="trust"
                  stroke="var(--color-chart-1)"
                  strokeWidth={2}
                  dot={{ fill: "var(--color-chart-1)", r: 4 }}
                />
              </LineChart>
            </ChartContainer>
            <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground border-t border-border pt-4">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5">
                  <span className="h-0.5 w-4 bg-warning" style={{ borderStyle: "dashed" }} />
                  Warning threshold (70)
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-0.5 w-4 bg-destructive" style={{ borderStyle: "dashed" }} />
                  Critical threshold (60)
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Attention Areas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {alerts.map((alert, index) => (
              <AlertItem key={index} {...alert} />
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {signalCategories.map((category) => (
          <Card key={category.name} className="border-border bg-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {category.name}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {category.signals.map((signal) => (
                <HealthBar
                  key={signal.label}
                  label={signal.label}
                  value={signal.value}
                  change={signal.change}
                  changeLabel="from baseline"
                />
              ))}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Intervention Window Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <div className="flex items-center justify-between">
              {[
                { label: "Policy Announced", status: "complete", difficulty: "Easy to Address" },
                { label: "Quiet Skepticism", status: "complete", difficulty: "Possible to Repair" },
                { label: "Passive Searching", status: "active", difficulty: "Difficult to Reverse" },
                { label: "Active Interviewing", status: "upcoming", difficulty: "Very Hard to Retain" },
                { label: "Resignation", status: "upcoming", difficulty: "Too Late" },
              ].map((stage, index) => (
                <div key={stage.label} className="flex flex-col items-center text-center">
                  <div
                    className={`h-4 w-4 rounded-full ${
                      stage.status === "complete"
                        ? "bg-muted-foreground"
                        : stage.status === "active"
                          ? "bg-warning ring-4 ring-warning/20"
                          : "bg-secondary border border-border"
                    }`}
                  />
                  <p className="mt-2 text-xs font-medium max-w-[100px]">{stage.label}</p>
                  <p
                    className={`mt-1 text-xs ${
                      stage.status === "active" ? "text-warning" : "text-muted-foreground"
                    }`}
                  >
                    {stage.difficulty}
                  </p>
                </div>
              ))}
            </div>
            <div className="absolute top-2 left-[10%] right-[10%] h-0.5 bg-border -z-10">
              <div className="h-full w-[45%] bg-muted-foreground" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
