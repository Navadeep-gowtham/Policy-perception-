"use client"

import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"

interface RegionCardProps {
  name: string
  policy: string
  engagement: number
  compliance: number
  attrition: number
  status: "on-track" | "attention" | "at-risk"
  className?: string
}

export function RegionCard({
  name,
  policy,
  engagement,
  compliance,
  attrition,
  status,
  className,
}: RegionCardProps) {
  const statusConfig = {
    "on-track": { label: "On Track", className: "bg-success/20 text-success border-success/30" },
    attention: { label: "Attention", className: "bg-warning/20 text-warning border-warning/30" },
    "at-risk": { label: "At Risk", className: "bg-destructive/20 text-destructive border-destructive/30" },
  }

  return (
    <div className={cn("rounded-lg border border-border bg-card p-4", className)}>
      <div className="flex items-start justify-between">
        <div>
          <h4 className="font-medium">{name}</h4>
          <p className="text-sm text-muted-foreground">{policy}</p>
        </div>
        <Badge variant="outline" className={statusConfig[status].className}>
          {statusConfig[status].label}
        </Badge>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-4">
        <div>
          <p className="text-xs text-muted-foreground">Engagement</p>
          <p className="text-lg font-semibold">{engagement}%</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Compliance</p>
          <p className="text-lg font-semibold">{compliance}%</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Attrition</p>
          <p className="text-lg font-semibold">{attrition}%</p>
        </div>
      </div>
    </div>
  )
}
