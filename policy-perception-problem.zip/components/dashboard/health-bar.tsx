"use client"

import { cn } from "@/lib/utils"

interface HealthBarProps {
  label: string
  value: number
  maxValue?: number
  change?: number
  changeLabel?: string
  className?: string
}

export function HealthBar({
  label,
  value,
  maxValue = 100,
  change,
  changeLabel = "from baseline",
  className,
}: HealthBarProps) {
  const percentage = Math.min((value / maxValue) * 100, 100)

  const getBarColor = (val: number) => {
    if (val >= 75) return "bg-success"
    if (val >= 50) return "bg-warning"
    return "bg-destructive"
  }

  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-medium">{value}%</span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
        <div
          className={cn("h-full transition-all duration-500", getBarColor(value))}
          style={{ width: `${percentage}%` }}
        />
      </div>
      {change !== undefined && (
        <p className="text-xs text-muted-foreground">
          <span className={change >= 0 ? "text-success" : "text-destructive"}>
            {change >= 0 ? "+" : ""}
            {change}%
          </span>{" "}
          {changeLabel}
        </p>
      )}
    </div>
  )
}
