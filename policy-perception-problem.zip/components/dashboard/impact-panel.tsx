"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  AreaChart,
  Area,
} from "recharts"

const timelineData = [
  { month: "Jan", collaboration: 78, engagement: 82, attendance: 45 },
  { month: "Feb", collaboration: 75, engagement: 79, attendance: 68 },
  { month: "Mar", collaboration: 71, engagement: 74, attendance: 82 },
  { month: "Apr", collaboration: 68, engagement: 70, attendance: 89 },
  { month: "May", collaboration: 72, engagement: 68, attendance: 91 },
  { month: "Jun", collaboration: 74, engagement: 71, attendance: 93 },
  { month: "Jul", collaboration: 76, engagement: 73, attendance: 92 },
  { month: "Aug", collaboration: 79, engagement: 76, attendance: 94 },
]

const chartConfig = {
  collaboration: {
    label: "Collaboration Quality",
    color: "var(--color-chart-1)",
  },
  engagement: {
    label: "Engagement Score",
    color: "var(--color-chart-2)",
  },
  attendance: {
    label: "Attendance Rate",
    color: "var(--color-chart-3)",
  },
} satisfies ChartConfig

const phaseConfig = [
  {
    phase: "Adaptation",
    months: "1-3",
    status: "complete",
    description: "Initial disruption period",
    metrics: ["Baseline established", "Friction signals captured", "Sentiment tracked"],
  },
  {
    phase: "Stabilization",
    months: "4-8",
    status: "active",
    description: "Behaviors settling, culture shifting",
    metrics: ["Interaction quality improving", "Meeting effectiveness mixed", "Retention signals emerging"],
  },
  {
    phase: "Impact",
    months: "9-18",
    status: "upcoming",
    description: "Meaningful outcomes measurable",
    metrics: ["Business outcomes pending", "Network analysis scheduled", "Full engagement review"],
  },
]

export function ImpactPanel() {
  return (
    <div className="space-y-6">
      <Card className="border-border bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Phased Measurement Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            {phaseConfig.map((phase) => (
              <div
                key={phase.phase}
                className={`rounded-lg border p-4 ${
                  phase.status === "active"
                    ? "border-chart-1 bg-chart-1/5"
                    : phase.status === "complete"
                      ? "border-success/30 bg-success/5"
                      : "border-border bg-secondary/30"
                }`}
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">{phase.phase}</h4>
                  <Badge
                    variant="outline"
                    className={
                      phase.status === "active"
                        ? "border-chart-1/50 text-chart-1 bg-chart-1/10"
                        : phase.status === "complete"
                          ? "border-success/50 text-success bg-success/10"
                          : "border-border text-muted-foreground"
                    }
                  >
                    {phase.status === "active" ? "In Progress" : phase.status === "complete" ? "Complete" : "Upcoming"}
                  </Badge>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  Months {phase.months}
                </p>
                <p className="mt-2 text-sm text-muted-foreground">
                  {phase.description}
                </p>
                <ul className="mt-3 space-y-1">
                  {phase.metrics.map((metric) => (
                    <li key={metric} className="text-xs text-muted-foreground flex items-center gap-2">
                      <span className={`h-1.5 w-1.5 rounded-full ${phase.status === "complete" ? "bg-success" : phase.status === "active" ? "bg-chart-1" : "bg-muted-foreground"}`} />
                      {metric}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-border bg-card">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Leading vs Lagging Indicators Over Time
            </CardTitle>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-3" />
                Attendance (Leading)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-1" />
                Collaboration (Lagging)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-2" />
                Engagement (Lagging)
              </span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[300px] w-full">
            <AreaChart data={timelineData}>
              <defs>
                <linearGradient id="colorAttendance" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-chart-3)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="var(--color-chart-3)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorCollaboration" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-chart-1)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="var(--color-chart-1)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorEngagement" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-chart-2)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="var(--color-chart-2)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }} />
              <YAxis domain={[40, 100]} tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Area
                type="monotone"
                dataKey="attendance"
                stroke="var(--color-chart-3)"
                fill="url(#colorAttendance)"
                strokeWidth={2}
              />
              <Area
                type="monotone"
                dataKey="collaboration"
                stroke="var(--color-chart-1)"
                fill="url(#colorCollaboration)"
                strokeWidth={2}
              />
              <Area
                type="monotone"
                dataKey="engagement"
                stroke="var(--color-chart-2)"
                fill="url(#colorEngagement)"
                strokeWidth={2}
              />
            </AreaChart>
          </ChartContainer>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-border bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Key Insight
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-warning/30 bg-warning/5 p-4">
              <p className="text-sm font-medium text-foreground">
                Attendance-Engagement Divergence Detected
              </p>
              <p className="mt-2 text-sm text-muted-foreground">
                Attendance reached 94% while engagement dropped to 71%. This 23-point gap suggests compliance without commitment — a leading indicator of future attrition risk.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Survivorship Bias Check
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Voluntary exits (6mo)</span>
                <span className="font-medium">47 employees</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Avg exit engagement score</span>
                <span className="font-medium text-destructive">58%</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Remaining avg engagement</span>
                <span className="font-medium">71%</span>
              </div>
              <p className="text-xs text-warning pt-2 border-t border-border">
                Warning: 13-point gap indicates metrics may be artificially elevated by attrition of disengaged employees.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
