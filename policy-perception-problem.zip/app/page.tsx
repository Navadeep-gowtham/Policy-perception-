"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { FairnessPanel } from "@/components/dashboard/fairness-panel"
import { ImpactPanel } from "@/components/dashboard/impact-panel"
import { EarlyWarningPanel } from "@/components/dashboard/early-warning-panel"
import { RegionalPanel } from "@/components/dashboard/regional-panel"
import {
  Scale,
  Clock,
  AlertTriangle,
  Globe,
  Calendar,
  ChevronDown,
  MoreHorizontal,
  Download,
  Settings,
  Bell,
} from "lucide-react"

export default function WorkforceDashboard() {
  const [selectedRegion, setSelectedRegion] = useState("all")
  const [timeRange, setTimeRange] = useState("last-6-months")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="flex h-14 items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="h-6 w-6 rounded bg-foreground" />
              <span className="font-semibold">Workforce</span>
              <Badge variant="outline" className="ml-1 text-xs">
                Enterprise
              </Badge>
            </div>
            <span className="text-muted-foreground">/</span>
            <span className="text-muted-foreground">Presence Strategy</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Bell className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Settings className="h-4 w-4" />
            </Button>
            <div className="ml-2 h-8 w-8 rounded-full bg-muted" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-6 py-6">
        {/* Page Title & Controls */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-balance">
              Presence Strategy Dashboard
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              RTO policy impact analysis across fairness, engagement, early warning signals, and regional adaptation
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Region" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Regions</SelectItem>
                <SelectItem value="americas">Americas</SelectItem>
                <SelectItem value="emea">EMEA</SelectItem>
                <SelectItem value="apac">Asia-Pacific</SelectItem>
              </SelectContent>
            </Select>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[160px]">
                <Calendar className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Time Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="last-30-days">Last 30 days</SelectItem>
                <SelectItem value="last-3-months">Last 3 months</SelectItem>
                <SelectItem value="last-6-months">Last 6 months</SelectItem>
                <SelectItem value="last-12-months">Last 12 months</SelectItem>
              </SelectContent>
            </Select>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-9 w-9">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Share Dashboard</DropdownMenuItem>
                <DropdownMenuItem>Schedule Report</DropdownMenuItem>
                <DropdownMenuItem>Configure Alerts</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="mt-6 grid gap-4 md:grid-cols-4">
          <div className="rounded-lg border border-border bg-card p-4">
            <div className="flex items-center gap-2">
              <Scale className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Fairness Index</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-semibold">67%</span>
              <span className="text-sm text-destructive">-12%</span>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">Perceived equity across roles</p>
          </div>

          <div className="rounded-lg border border-border bg-card p-4">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Impact Phase</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-semibold">2/3</span>
              <Badge variant="outline" className="text-xs">Stabilization</Badge>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">Month 5 of measurement cycle</p>
          </div>

          <div className="rounded-lg border border-warning/30 bg-warning/5 p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-warning" />
              <span className="text-sm text-muted-foreground">Trust Health</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-semibold">63%</span>
              <span className="text-sm text-destructive">-19%</span>
            </div>
            <p className="mt-1 text-xs text-warning">Approaching critical threshold</p>
          </div>

          <div className="rounded-lg border border-border bg-card p-4">
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Regional Variance</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-semibold">23pt</span>
              <span className="text-sm text-warning">High</span>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">Engagement gap across regions</p>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="fairness" className="mt-8">
          <TabsList className="w-full justify-start gap-1 bg-transparent p-0 h-auto">
            <TabsTrigger
              value="fairness"
              className="data-[state=active]:bg-secondary data-[state=active]:border-b-2 data-[state=active]:border-foreground rounded-none px-4 py-2"
            >
              <Scale className="mr-2 h-4 w-4" />
              Fairness Perception
            </TabsTrigger>
            <TabsTrigger
              value="impact"
              className="data-[state=active]:bg-secondary data-[state=active]:border-b-2 data-[state=active]:border-foreground rounded-none px-4 py-2"
            >
              <Clock className="mr-2 h-4 w-4" />
              Phased Impact
            </TabsTrigger>
            <TabsTrigger
              value="warning"
              className="data-[state=active]:bg-secondary data-[state=active]:border-b-2 data-[state=active]:border-foreground rounded-none px-4 py-2"
            >
              <AlertTriangle className="mr-2 h-4 w-4" />
              Early Warning
              <Badge variant="destructive" className="ml-2 h-5 px-1.5 text-xs">
                4
              </Badge>
            </TabsTrigger>
            <TabsTrigger
              value="regional"
              className="data-[state=active]:bg-secondary data-[state=active]:border-b-2 data-[state=active]:border-foreground rounded-none px-4 py-2"
            >
              <Globe className="mr-2 h-4 w-4" />
              Regional Adaptation
            </TabsTrigger>
          </TabsList>

          <div className="mt-6">
            <TabsContent value="fairness" className="m-0">
              <FairnessPanel />
            </TabsContent>

            <TabsContent value="impact" className="m-0">
              <ImpactPanel />
            </TabsContent>

            <TabsContent value="warning" className="m-0">
              <EarlyWarningPanel />
            </TabsContent>

            <TabsContent value="regional" className="m-0">
              <RegionalPanel />
            </TabsContent>
          </div>
        </Tabs>

        {/* Footer Note */}
        <div className="mt-8 rounded-lg border border-border bg-secondary/30 p-4">
          <p className="text-sm text-muted-foreground">
            <span className="font-medium text-foreground">Measurement Philosophy:</span>{" "}
            This dashboard prioritizes lagging indicators (collaboration quality, engagement depth, retention) over leading indicators (attendance, badge swipes). 
            High compliance with low engagement signals coerced presence, not successful policy adoption.
          </p>
        </div>
      </main>
    </div>
  )
}
